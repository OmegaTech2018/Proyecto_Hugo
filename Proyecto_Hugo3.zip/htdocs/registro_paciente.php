<?php
	require_once("sesion.php");

	$usuario=$_SESSION["usuario"];
	$nombre=$_SESSION["nombre_pasante"];
	if (!isset($sistema)) {
		require_once("coneccion.php");
		$sistema=new sistema();
		$sistema->conectar();
	}
	$opcion_nota=$_GET["opcion_nota"];
	//echo $usuario." ".$nombre;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registro Paciente</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="demo-files/demo.css">
	<link rel="stylesheet" href="css/estilo_bienvenido.css" type="text/css">
	<script src="js/div.js"></script>
    <script src="js/funcion.js"></script><!--CONTIENE LA FUNCION PARA QUE LA PESTAÑA AL DARLE CLICK MUESTRE LO INDICADO-->
</head>
<body>
<section id="contenedor">
	<header><h1><?php echo $nombre; ?><br><br>Formulario de Registro de Paciente</h1></header>
	<section id="formulario_paciente">
		<form action="guardar_nota_paciente.php" method="post" target="guarda_paciente">
			<input type="hidden" name="formulario" id="formulario" value="1">
			<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
			<input type="hidden" name="opcion_nota" id="opcion_nota" value="<?php echo  $opcion_nota; ?>">
			<p>Fecha: <?php echo date("d-m-Y"); ?></p>
            <hr>
            <h1><strong>Datos personales del paciente</strong></h1>
            <?php 
            	/*SE AGREGA UNA NUEVA NOTA DE UN PACIENTE NUEVO*/
            	if ($opcion_nota==4) {
            		require_once("nota_nueva_paciente_nuevo.html");
            	}
            	/*SE AGREGA UNA NUEVA NOTA DE UN PACIENTE YA EXISTENTE*/
            	if ($opcion_nota==3) {
            		require_once("nota_nueva_paciente_existente.php");
            	}
             ?>
             <input type="submit" value="Guardar Paciente">
		</form>
		<iframe name="guarda_paciente" id="guarda_paciente" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>

		<hr size="2px" color="black">	
		
		<form action="guardar_nota_paciente.php" method="post" target="guarda_nota">
			<input type="hidden" name="formulario" id="formulario" value="2">
            <input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
            <h1><strong>Signos Vitales</strong></h1>
            <p>Frecuencia Cardiaca: <input type="text" id="fc" name="fc" required="required">
				Frecuencia Respiratoria: <input type="text" id="fr" name="fr" required="required">
				Presi&oacute;n Arterial: <input type="text" id="pa" name="pa" required="required"></p>
			<p>Temperatura: <input type="text" id="temp" name="temp" required="required">
			Peso: <input type="text" id="pe" name="pe" required="required">
			Talla: <input type="text" id="talla" name="talla" required="required">
            Indice de masa corporal: <input type="text" id="imc" name="imc" required="required"></p>
            <p>DxTx: <input type="text" id="dxtx" name="dxtx"></p>
			<h1><strong>Nota</strong></h1>
            <textarea rows="20" cols="150" id="texto_nota" name="texto_nota" required></textarea>
            <br><br>
            <input type="submit" value="Guardar Nota">
		</form>
		<iframe name="guarda_nota" id="guarda_nota" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>	

		<hr size="2px" color="black">

        <h1><strong>Laboratorio</strong></h1>
        <form action="guardar_laboratorios.php" method="post" target="sql_guarda_laboratorio_BH">
			<input type="hidden" name="form_laboratorio" id="form_laboratorio" value="1">
			<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
            <h2>BH</h2>
				<p>
            		Eritrocitos: <input type="text" id="eritocitros_vista" name="eritocitros_vista"> 
					Hemoglobina: <input type="text" id="hemoglobina_vista" name="hemoglobina_vista">
				</p>
				<p>
					Hematocrito: <input type="text" id="hematrocito_vista" name="hematrocito_vista"> 
					Plaquetas: <input type="text" id="plaquetas_vista" name="plaquetas_vista">
				</p>
				<p>
					Leucocitos: <input type="text" id="leucocitos_vista" name="leucocitos_vista">
					Volumen corpuscular medio: <input type="text" id="volumen_corpuslar_medio_vista" name="volumen_corpuslar_medio_vista">
				</p>
				<p>
					Neutrofilos: <input type="text" id="neutrofilos_vista" name="neutrofilos_vista">
					Eosinofilos: <input type="text" id="eosinofilos_vista" name="eosinofilos_vista">
				</p>
			<input type="submit" value="Guardar BH">
		</form>
		<iframe name="sql_guarda_laboratorio_BH" id="sql_guarda_laboratorio_BH" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>
			
		<hr>
			
		<form action="guardar_laboratorios.php" method="post" target="sql_guarda_laboratorio_QS">
			<input type="hidden" name="form_laboratorio" id="form_laboratorio" value="2">
			<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
			<h2>QS</h2>
  				<p>
            		Glucosa: <input type="text" id="glucosa_vista" name="glucosa_vista"> 
					Urea: <input type="text" id="urea_vista" name="urea_vista"> 
				</p>
				<p>
					Creatinina:<input type="text" id="creatinina_vista" name="creatinina_vista">
					Acido urico: <input type="text" id="acido_urico_vista" name="acido_urico_vista"> 
				</p>
				<p>
					Colesterol: <input type="text" id="colesterol_vista" name="colesterol_vista"> 
					Trigliceridos: <input type="text" id="trigliceridos_vista" name="trigliceridos_vista">
				</p>
				<p>
					B total: <input type="text" id="btotal_vista" name="btotal_vista">
					B directa: <input type="text" id="bdirecta_vista" name="bdirecta_vista">
					B indirecta: <input type="text" id="bindirecta_vista" name="bindirecta_vista">
				</p>
				<p>
					TGO: <input type="text" id="tgo_vista" name="tgo_vista">
					TGP: <input type="text" id="tgp_vista" name="tgp_vista">
				</p>
				<p>
					Amilasa: <input type="text" id="amilasa_vista" name="amilasa_vista">
					Lipasa: <input type="text" id="lipasa_vista" name="lipasa_vista">
            	</p>
            	<input type="submit" value="Guardar QS">
			</form>
			<iframe name="sql_guarda_laboratorio_QS" id="sql_guarda_laboratorio_QS" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>
            
            <hr>

            <form action="guardar_laboratorios.php" method="post" target="sql_guarda_labortorio_EGO">
				<input type="hidden" name="form_laboratorio" id="form_laboratorio" value="3">
				<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
				<h2>EGO</h2>
  					 <p>
            			Densidad: <input type="text" id="densidad_vista" name="densidad_vista">
						PH: <input type="text" id="ph_vista" name="ph_vista">
					 </p>
					 <p>
						Celulas epiteliales: <input type="text" id="celulas_epiteliales_vista" name="celulas_epiteliales_vista">
						Cristales: <input type="text" id="cristales_vista" name="cristales_vista">
					 </p>
					 <p>
						Leucocitos: <input type="text" id="leucocitos_vista" name="leucocitos_vista">
						Eritrocitos: <input type="text" id="eritrocitos_vista" name="eritrocitos_vista">
					 </p>
					 <p>
						Glucosa: <input type="text" id="glucosa_vista" name="glucosa_vista">
						Bacterias: <input type="text" id="bacterias_vista" name="bacterias_vista">
            		 </p>
            		 <input type="submit" value="Guardar EGO">
			</form>
			<iframe name="sql_guarda_labortorio_EGO" id="sql_guarda_labortorio_EGO" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>
            
            <hr>
            
            <form action="guardar_laboratorios.php" method="post" target="sql_guarda_laboratorio_Cultivos">
				<input type="hidden" name="form_laboratorio" id="form_laboratorio" value="4">
				<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
				<h2>Cultivos</h2>
  					 <textarea rows="20" cols="150" id="cultivos_texto_vista" name="cultivos_texto_vista"></textarea>
  					 <br><br>
  				<input type="submit" value="Guardar Cultivos">
			</form>
			<iframe name="sql_guarda_laboratorio_Cultivos" id="sql_guarda_laboratorio_Cultivos" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>

		<hr size="2px" color="black">
            
        <h1><strong>Gabinete</strong></h1>
        <form action="Gabinete/guardar_nota_gabinete.php" method="post" target="guarda_electrocardiograma" enctype="multipart/form-data">
        	<input type="hidden" name="form_gabinete" id="form_gabinete" value="1">
			<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
            	<ul>
				<li><h2>Electrocardiogramas</h2></li>
					<input name="gelectro1" type="file" />
            		<input name="gelectro2" type="file" />
            		<input name="gelectro3" type="file" />
            		<input name="gelectro4" type="file" />
            		<input name="gelectro5" type="file" />
            		<input name="gelectro6" type="file" />
            		<input name="gelectro7" type="file" />
            		<input name="gelectro8" type="file" />
            		<input name="gelectro9" type="file" />
            		<input name="gelectro10" type="file" />
            		<br><br>

			<input type="submit" value="Guardar Electrocardiogramas">
        </form>
        <iframe name="guarda_electrocardiograma" id="guarda_electrocardiograma" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>	

		<hr>
			
		<form action="Gabinete/guardar_nota_gabinete.php" method="post" target="guarda_papanicolaou">
			<input type="hidden" name="form_gabinete" id="form_gabinete" value="2">
			<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">	
				<li><h2>Papanicolaou</h2></li>
					<textarea rows="20" cols="60" id="papanicolaou" name="papanicolaou"></textarea>
					<br><br>
			<input type="submit" value="Guardar Papanicolaou">
		</form>
		<iframe name="guarda_papanicolaou" id="guarda_papanicolaou" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>
			
		<hr>
			
		<form action="Gabinete/guardar_nota_gabinete.php" method="post" target="guarda_ultrasonidos" enctype="multipart/form-data">
			<input type="hidden" name="form_gabinete" id="form_gabinete" value="3">
			<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
				<li><h2>Ultrasonidos</h2></li>
					<textarea rows="20" cols="60" id="ultrasonidos" name="ultrasonidos"></textarea>
					<br><br>
			<input type="submit" value="Guardar Ultrasonidos">
		</form>
		<iframe name="guarda_ultrasonidos" id="guarda_ultrasonidos" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>
			
		<hr>
			
		<form action="Gabinete/guardar_nota_gabinete.php" method="post" target="guarda_rayosx" enctype="multipart/form-data">
			<input type="hidden" name="form_gabinete" id="form_gabinete" value="4">
			<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
				<li><h2>Rayos X</h2></li>
					<input name="rayosxi_1" type="file" />
           			<input name="rayosxi_2" type="file" />
           			<input name="rayosxi_3" type="file" />
           			<input name="rayosxi_4" type="file" />
           			<input name="rayosxi_5" type="file" />
           			<input name="rayosxi_6" type="file" />
           			<input name="rayosxi_7" type="file" />
           			<input name="rayosxi_8" type="file" />
           			<input name="rayosxi_9" type="file" />
           			<input name="rayosxi_10" type="file" />
				</ul>	
           	<input type="submit" value="Guardar Rayos X">
		</form>
		<iframe name="guarda_rayosx" id="guarda_rayosx" src="vacia.html" width="100%" height="60" frameborder="0"></iframe>

        <hr size="2px" color="black">
            
        <form action="Imagen/guardar_nota_imagen.php" method="post" target="guarda_imagen" enctype="multipart/form-data">
           	<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
        	   	<h1><strong>Imagen</strong></h1>
            	<input name="imagen_1" type="file" />
            	<input name="imagen_2" type="file" />
            	<input name="imagen_3" type="file" />
            	<input name="imagen_4" type="file" />
            	<input name="imagen_5" type="file" />
            	<input name="imagen_6" type="file" />
            	<input name="imagen_7" type="file" />
            	<input name="imagen_8" type="file" />
            	<input name="imagen_9" type="file" />
            	<input name="imagen_10" type="file" />
            <br><br>
            <input type="submit" value="Guardar Imagen">
		</form>
		<iframe name="guarda_imagen" id="guarda_imagen" src="vacia.html" width="100%" height="200" frameborder="0"></iframe>
		<form action="guardar_nota_paciente.php" method="post">
			<input type="hidden" name="usuario" id="usuario" value="<?php echo  $usuario; ?>">
			<input type="hidden" name="nombre_pasante" id="nombre_pasante" value="<?php echo  $nombre; ?>">
			<input type="hidden" name="formulario" id="formulario" value="3">
			<br><br>
            <input type="submit" value="Salir de Nota">
		</form>
	</section>
</section>
</body>
</html>