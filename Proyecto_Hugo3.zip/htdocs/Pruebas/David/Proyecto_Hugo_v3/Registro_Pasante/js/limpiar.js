function Clean() {
	document.getElementById("form-clave").reset();
}