<?php
	echo "<h3>notas</h3>
  				<p>Última nota<br>
      		<a href=\"#\">Nueva nota</a>
  			</p>";
?>