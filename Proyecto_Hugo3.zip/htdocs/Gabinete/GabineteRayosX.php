<?php
	class GabineteRayosX{
		private $rayosxi_1;
		private $rayosxi_2;
		private $rayosxi_3;
		private $rayosxi_4;
		private $rayosxi_5;
		private $rayosxi_6;
		private $rayosxi_7;
		private $rayosxi_8;
		private $rayosxi_9;
		private $rayosxi_10;

		function GabineteRayosX($rayosxi_1,$rayosxi_2,$rayosxi_3,$rayosxi_4,$rayosxi_5,$rayosxi_6,$rayosxi_7,$rayosxi_8,$rayosxi_9,$rayosxi_10){
			$this->rayosxi_1 = $rayosxi_1;
			$this->rayosxi_2 = $rayosxi_2;
			$this->rayosxi_3 = $rayosxi_3;
			$this->rayosxi_4 = $rayosxi_4;
			$this->rayosxi_5 = $rayosxi_5;
			$this->rayosxi_6 = $rayosxi_6;
			$this->rayosxi_7 = $rayosxi_7;
			$this->rayosxi_8 = $rayosxi_8;
			$this->rayosxi_9 = $rayosxi_9;
			$this->rayosxi_10 = $rayosxi_10;
		}

		function setrayosxi_1($rayosxi_1){
			$this->rayosxi_1 = $rayosxi_1;
		}

		function getrayosxi_1(){
			return $this->rayosxi_1;
		}

		function setrayosxi_2($rayosxi_2){
			$this->rayosxi_2 = $rayosxi_2;
		}

		function getrayosxi_2(){
			return $this->rayosxi_2;
		}

		function setrayosxi_3($rayosxi_3){
			$this->rayosxi_3 = $rayosxi_3;
		}

		function getrayosxi_3(){
			return $this->rayosxi_3;
		}

		function setrayosxi_4($rayosxi_4){
			$this->rayosxi_4 = $rayosxi_4;
		}

		function getrayosxi_4(){
			return $this->rayosxi_4;
		}

		function setrayosxi_5($rayosxi_5){
			$this->rayosxi_5 = $rayosxi_5;
		}

		function getrayosxi_5(){
			return $this->rayosxi_5;
		}

		function setrayosxi_6($rayosxi_6){
			$this->rayosxi_6 = $rayosxi_6;
		}

		function getrayosxi_6(){
			return $this->rayosxi_6;
		}

		function setrayosxi_7($rayosxi_7){
			$this->rayosxi_7 = $rayosxi_7;
		}

		function getrayosxi_7(){
			return $this->rayosxi_7;
		}		

		function setrayosxi_8($rayosxi_8){
			$this->rayosxi_8 = $rayosxi_8;
		}

		function getrayosxi_8(){
			return $this->rayosxi_8;
		}

		function setrayosxi_9($rayosxi_9){
			$this->rayosxi_9 = $rayosxi_9;
		}

		function getrayosxi_9(){
			return $this->rayosxi_9;
		}

		function setrayosxi_10($rayosxi_10){
			$this->rayosxi_10 = $rayosxi_10;
		}

		function getrayosxi_10(){
			return $this->rayosxi_10;
		}
	}
?>