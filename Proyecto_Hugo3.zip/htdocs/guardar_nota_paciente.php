<!DOCTYPE html>
<html>
<head>
	<title>Guardar Nota Paciente</title>
</head>
<body>
	<?php
		require_once("coneccion.php");

		$sistema = new sistema();
        $sistema->conectar();
        $usuario=$sistema->recuperaPOST("usuario","Por favor inice sesión");
        //echo $usuario." ".$opcion_nota;
        $fecha=date("Y-m-d");
        $formulario=$_POST['formulario'];

        switch ($formulario) {
        	case 1:
        		$ap_paterno=$sistema->recuperaPOST("ap_paterno","Apellido paterno es requerido");
                $ap_materno=$sistema->recuperaPOST("ap_materno","Apellido materno es requerido");
                $nombre=$sistema->recuperaPOST("nombre","Nombre es requerido");
                $edad=$sistema->recuperaPOST("edad","La edad del paciente es requerida");
                $domicilio=$sistema->recuperaPOST("domicilio","El domicilio es requerido");
                $embarazo=$sistema->recuperaPOST("embarazo","Es necesario saber si el paciente esta embarazada ");
                $telefono=$_POST["telefono"];
                $opcion_nota=$sistema->recuperaPOST("opcion_nota","Error, inicie de nuevo sesión");

                /*SE AGREGA UNA NUEVA NOTA DE UN PACIENTE NUEVO*/
                if ($opcion_nota==4) {
                	$recien_nacido=$sistema->recuperaPOST("recien_nacido","Es necesario saber si el paciente es recien nacido");
                	/*GUARDAMOS LOS DATOS DEL PACIENTE*/
                	$sql_guarda_paciente=sprintf("INSERT INTO paciente (apellido_paterno,apellido_materno,nombre,edad_paciente,embarazo,
                	recien_nacido,domicilio,telefono,paciente_activo) VALUES ('$ap_paterno','$ap_materno','$nombre','$edad','$embarazo',
                	'$recien_nacido','$domicilio','$telefono',1);");
                	if ($sistema->enlaceBD->query($sql_guarda_paciente)) {
                		/*INSERTO UNA NOTA NUEVA CON EL ID DEL PACIENTE PARA OBTENER EL ID DE LA NOTA*/
                		$sql_guarda_nota=sprintf("INSERT INTO nota (paciente_id,email,fecha_nota,frecuencia_cardiaca,frecuencia_respiratoria,
                                                  presion_arterial,temperatura,peso,talla,indice_masa_corporal,DxTx,texto_nota) 
                                                  SELECT paciente_id,'$usuario','$fecha',0,0,0,0,0,0,0,0,0 
                                                  FROM paciente WHERE apellido_paterno='$ap_paterno' 
                                                  AND apellido_materno='$ap_materno' AND nombre='$nombre' AND paciente_activo=1;");
                		if ($sistema->enlaceBD->query($sql_guarda_nota)) {
                			//echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                            /*GUARDAMOS GABINETES*/
                            $sql_electro=sprintf("INSERT INTO gabinete_electrocardiogramas (nota_id,bandera) 
                                                  SELECT MAX(n.nota_id),0 FROM nota n INNER JOIN paciente p ON n.paciente_id=p.paciente_id 
                                                  WHERE apellido_paterno='$ap_paterno' AND apellido_materno='$ap_materno' 
                                                  AND nombre='$nombre' AND paciente_activo=1;");
                            if ($sistema->enlaceBD->query($sql_electro)) {
                                //echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                $sql_papanicolaou=sprintf("INSERT INTO gabinete_papanicolaou (nota_id,bandera,papanicolaou_descripcion)
                                                           SELECT MAX(n.nota_id),0,0 FROM nota n INNER JOIN paciente p ON 
                                                           n.paciente_id=p.paciente_id WHERE apellido_paterno='$ap_paterno' 
                                                           AND apellido_materno='$ap_materno' AND nombre='$nombre' AND 
                                                           paciente_activo=1;");
                                if ($sistema->enlaceBD->query($sql_papanicolaou)) {
                                    //echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                    $sql_ultrasonidos=sprintf("INSERT INTO gabinete_ultrasonidos (nota_id,bandera,ultrasonido_descripcion)
                                                               SELECT MAX(n.nota_id),0,0 FROM nota n INNER JOIN paciente p ON 
                                                               n.paciente_id=p.paciente_id WHERE apellido_paterno='$ap_paterno' 
                                                               AND apellido_materno='$ap_materno' AND nombre='$nombre' AND 
                                                               paciente_activo=1;");
                                    if ($sistema->enlaceBD->query($sql_ultrasonidos)) {
                                        //echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                        $sql_rayosx=sprintf("INSERT INTO gabinete_rayosx (nota_id,bandera) 
                                                            SELECT MAX(n.nota_id),0 FROM nota n INNER JOIN paciente p ON 
                                                            n.paciente_id=p.paciente_id 
                                                            WHERE apellido_paterno='$ap_paterno' AND apellido_materno='$ap_materno' 
                                                            AND nombre='$nombre' AND paciente_activo=1;") ;
                                        if ($sistema->enlaceBD->query($sql_rayosx)) {
                                            //echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                            /*GUARDAMOS IMAGEN*/
                                            $sql_imagen=sprintf("INSERT INTO imagen (nota_id,bandera) SELECT MAX(n.nota_id),0 
                                                                 FROM nota n INNER JOIN paciente p ON n.paciente_id=p.paciente_id
                                                                 WHERE apellido_paterno='$ap_paterno' AND apellido_materno='$ap_materno' 
                                                                 AND nombre='$nombre' AND paciente_activo=1;"); 
                                            if ($sistema->enlaceBD->query($sql_imagen)) {
                                                   echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                            }   
                                        }   
                                    }
                                }
                            }
                		}
                	}else{
                		if (substr_count(mysqli_error($sistema->enlaceBD), "Duplicate")) {
                            echo "<center><strong>El paciente ya se ha guardado.</strong></center>";
                        }else{
                            echo "<center><strong>Error al guardar los datos del paciente<br>Por favor vuelve a intentarlo en 30 segundos.</strong></center>";
                        }
                	}
                	$sistema->desconectar();
                }
                /*SE ACTUALIZAN LOS DATOS DE UN PACIENTE QUE YA EXISTE*/
                if ($opcion_nota==3) {
                	$paciente_id=$sistema->recuperaPOST("paciente_id","Es necesario el identificador del paciente");
                    $recien_nacido="No";
                    $sql_actualiza_domicilio=sprintf("UPDATE paciente SET domicilio='$domicilio',telefono='$telefono',edad_paciente=$edad,
                    embarazo='$embarazo' WHERE paciente_id=$paciente_id;");
                    if ($sistema->enlaceBD->query($sql_actualiza_domicilio)){
                    	/*INSERTO UNA NOTA NUEVA CON EL ID DEL PACIENTE PARA OBTENER EL ID DE LA NOTA*/
                    	$sql_guarda_nota=sprintf("INSERT INTO nota (paciente_id,email,fecha_nota,frecuencia_cardiaca,frecuencia_respiratoria,
                                                  presion_arterial,temperatura,peso,talla,indice_masa_corporal,DxTx,texto_nota) 
                                                  VALUES ($paciente_id,'$usuario','$fecha',0,0,0,0,0,0,0,0,0);");
                		if ($sistema->enlaceBD->query($sql_guarda_nota)) {
                			//echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                            /*GUARDAMOS GABINETES*/
                            $sql_electro=sprintf("INSERT INTO gabinete_electrocardiogramas (nota_id,bandera) 
                                                  SELECT MAX(n.nota_id),0 FROM nota n INNER JOIN paciente p ON n.paciente_id=p.paciente_id 
                                                  WHERE p.paciente_id=$paciente_id AND paciente_activo=1;");
                            if ($sistema->enlaceBD->query($sql_electro)) {
                                //echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                $sql_papanicolaou=sprintf("INSERT INTO gabinete_papanicolaou (nota_id,bandera,papanicolaou_descripcion)
                                                           SELECT MAX(n.nota_id),0,0 FROM nota n INNER JOIN paciente p ON 
                                                           n.paciente_id=p.paciente_id WHERE p.paciente_id=$paciente_id AND 
                                                           paciente_activo=1;");
                                if ($sistema->enlaceBD->query($sql_papanicolaou)) {
                                    //echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                    $sql_ultrasonidos=sprintf("INSERT INTO gabinete_ultrasonidos (nota_id,bandera,ultrasonido_descripcion)
                                                               SELECT MAX(n.nota_id),0,0 FROM nota n INNER JOIN paciente p ON 
                                                               n.paciente_id=p.paciente_id WHERE p.paciente_id=$paciente_id AND 
                                                               paciente_activo=1;");
                                    if ($sistema->enlaceBD->query($sql_ultrasonidos)) {
                                        //echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                        $sql_rayosx=sprintf("INSERT INTO gabinete_rayosx (nota_id,bandera) 
                                                            SELECT MAX(n.nota_id),0 FROM nota n INNER JOIN paciente p ON 
                                                            n.paciente_id=p.paciente_id 
                                                            WHERE p.paciente_id=$paciente_id AND paciente_activo=1;") ;
                                        if ($sistema->enlaceBD->query($sql_rayosx)) {
                                            //echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                            /*GUARDAMOS IMAGEN*/
                                            $sql_imagen=sprintf("INSERT INTO imagen (nota_id,bandera) SELECT MAX(n.nota_id),0 
                                                                 FROM nota n INNER JOIN paciente p ON n.paciente_id=p.paciente_id
                                                                 WHERE p.paciente_id=$paciente_id AND paciente_activo=1;"); 
                                            if ($sistema->enlaceBD->query($sql_imagen)) {
                                                   echo "<center><strong>Datos del paciente guardados con éxito.</strong></center>";
                                            }   
                                        }   
                                    }
                                }
                            }
                		}
                    }
                }
        	break;
        	case '2':
        		$sql_nota_id=sprintf("SELECT Max(nota_id) AS nota_id FROM nota n INNER JOIN paciente p ON p.paciente_id=n.paciente_id 
                                      WHERE n.email='$usuario' AND p.paciente_activo=1;");
        		if($sistema->enlaceBD->query($sql_nota_id)){
        			$nota_id=$sistema->getBD($sql_nota_id,"nota_id");
                    $fc=$sistema->recuperaPOST("fc","La frecuecnia cardiaca es requerida");
                    $fr=$sistema->recuperaPOST("fr","La frecuencia respiratoria es requerida");
                    $pa=$sistema->recuperaPOST("pa","La presión arterial es requerida");
                    $temp=$sistema->recuperaPOST("temp","La temperatura es requerida");
                    $pe=$sistema->recuperaPOST("pe","El peso es requerida");
                    $talla=$sistema->recuperaPOST("talla","La talla es requerida");
                    $imc=$sistema->recuperaPOST("imc","El indice de masa corporal es requerido");
                    $dxtx=$_POST['dxtx'];
                    $texto_nota=$sistema->recuperaPOST("texto_nota","Los comentarios de la nota son requeridos");
                    /*GUARDAMOS LA NOTA CON LOS VALORE CORRECTOS*/
                    $sql_guarda_nota=sprintf("UPDATE nota SET fecha_nota='$fecha',frecuencia_cardiaca='$fc',                 	frecuencia_respiratoria='$fr',presion_arterial='$pa',temperatura=$temp,peso=$pe,talla=$talla,
                    	indice_masa_corporal=$imc,DxTx=$dxtx,texto_nota='$texto_nota' WHERE email='$usuario' AND nota_id=$nota_id;");
                    if ($sistema->enlaceBD->query($sql_guarda_nota)) {
                        echo "<center><strong>Datos de la nota guardados con éxito.</strong></center>";
                    }else{
                        if(substr_count(mysqli_error($sistema->enlaceBD), "Duplicate")){
                            echo "<center><strong>La nota ya se ha guardado.</strong></center>";
                        }else{
                            echo "<center><strong>Error al guardar la nota<br>Por favor vuelve a intentarlo en 30 segundos.</strong></center>";
                        }
                    }$sistema->desconectar();
        		}
        	break;
        	case 3:
        		?>
        			<center>
           			<form action="bienvenido.php" method="post" name="regresar" target="_top">
               			<input  style="font-size:24px" type="submit" value="Cerrar expediente" /><br />
           			</form>
	       			<form action="agendar_cita.php" method="post" name="agendar_cita" target="_top">
               			<input  style="font-size:24px" type="submit" value="Agendar Cita" /><br />
           			</form>
    				</center>
        		<?php
        	break;
        }
	?>
</body>
</html>