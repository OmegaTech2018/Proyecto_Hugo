<?php
	echo "
  			<p>
  				<a href=\"Laboratorio/lista_laboratorio.php?nombre_paciente=$nombre_paciente&paciente_id=$paciente_id&laboratorio=1\" target=\"_blank\">BH</a><br>
  				<a href=\"Laboratorio/lista_laboratorio.php?nombre_paciente=$nombre_paciente&paciente_id=$paciente_id&laboratorio=2\" target=\"_blank\">QS</a><br>
  				<a href=\"Laboratorio/lista_laboratorio.php?nombre_paciente=$nombre_paciente&paciente_id=$paciente_id&laboratorio=3\" target=\"_blank\">EGO</a><br>
  				<a href=\"Laboratorio/lista_laboratorio.php?nombre_paciente=$nombre_paciente&paciente_id=$paciente_id&laboratorio=4\" target=\"_blank\">Cultivos</a><br>
  			</p>";
?>