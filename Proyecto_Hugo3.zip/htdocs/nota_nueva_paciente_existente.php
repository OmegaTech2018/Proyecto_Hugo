<?php
    $paciente_id=$_GET['paciente_id'];
    $sql_busca_paciente=sprintf("SELECT nombre, apellido_paterno,apellido_materno,domicilio,telefono FROM paciente WHERE paciente_id=$paciente_id;");
    $Nombre=$sistema->getBD($sql_busca_paciente,"nombre");
    $Ap_Paterno=$sistema->getBD($sql_busca_paciente,"apellido_paterno");
    $Ap_Materno=$sistema->getBD($sql_busca_paciente,"apellido_materno");
    $Domicilio=$sistema->getBD($sql_busca_paciente,"domicilio");
    $Telefono=$sistema->getBD($sql_busca_paciente,"telefono");
?>
<input type="hidden" name="paciente_id" id="paciente_id" value="<?php echo  $paciente_id; ?>">
<p>
	Apellido Paterno: <input type="text" id="ap_paterno" name="ap_paterno" value="<?php echo $Ap_Paterno; ?>" readonly="readonly">
	Apellido Materno: <input type="text" id="ap_materno" name="ap_materno" value="<?php echo $Ap_Materno; ?>" readonly="readonly">
	Nombre(s): <input type="text" id="nombre" name="nombre" value="<?php echo $Nombre; ?>" readonly="readonly">
</p>
<p>Edad: <input type="number" id="edad" name="edad" required="required"></p>
<p>Domicilio: <input type="text" id="domicilio" name="domicilio" value="<?php echo $Domicilio; ?>"></p>
<p>Embarazo:
	<div class="select">
        <select name="embarazo" id="embarazo" required="required">
            <option value="" selected="selected" disabled="disabled">&nbsp;</option>
            <option value="Si">Si</option>
            <option value="No">No</option>
        </select>
    </div>
</p>
<p>Tel&eacute;fono: <input type="text" id="telefono" name="telefono" value="<?php echo $Telefono; ?>"></p>